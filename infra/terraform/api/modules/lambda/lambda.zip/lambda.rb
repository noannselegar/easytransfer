def handler(event:, context:)
  puts "Hello world!"
end
